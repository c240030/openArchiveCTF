// SPDX-License-Identifier: MIT
pragma solidity ^0.8.27;

enum ProcessingMode {
    None,
    RequestPrice
}
